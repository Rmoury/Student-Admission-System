package com.jsp.urs.controller;

import java.util.List;

import javax.persistence.TypedQuery;

import com.jsp.urs.model.Student;
import com.jsp.urs.servlet.DatabaseConnection;

public class ValidationController {

	public boolean addStudent(Student student) {
		if (student != null) {
			DatabaseConnection.entityTransaction.begin();
			DatabaseConnection.entityManager.persist(student);
			DatabaseConnection.entityTransaction.commit();
			return true;
		}
		return false;
	}

	public Student searchStudent(String username, String password) {
		Student student = DatabaseConnection.entityManager.find(Student.class, username);
		if (student != null) {
			if (student.getUsername().equals(username) && student.getPassword().equals(password)) {
				return student;
				
			}
		}
		return null;
	}

	public Student searchUsername(String username) {
		Student student = DatabaseConnection.entityManager.find(Student.class, username);
		if (student != null) {
			if (student.getUsername().equals(username)) {
				return student;
			}
		}
		return student;
	}

	public Student searchUsernameforPassword(String username) {
		Student student = DatabaseConnection.entityManager.find(Student.class, username);
		if (student != null) {
				return student;
		}
		return null;
	}

	public boolean updateUserPasswordByUserName(Student student, String User_password) {
		if (student != null) {
			student.setUsername(student.getUsername());
			student.setPassword(User_password);
			DatabaseConnection.entityTransaction.begin();
			DatabaseConnection.entityManager.merge(student);
			DatabaseConnection.entityTransaction.commit();
			return true;
		}
		return false;
	}
	
	public boolean findAdmin(Student user) {
		if (user.getUsername().equals("admin123") && user.getPassword().equals("admin123")) {
			System.out.println("Find admin");
			return true;
		}
		System.out.println("No Find");
		return false;
	}
	
	public List<Student> allStudent() {
		String jpql = "SELECT std FROM Student std";
		
		TypedQuery<Student> query = DatabaseConnection.entityManager.createQuery(jpql, Student.class);
		
		return query.getResultList();
	}
	
	public boolean deleteStudent(String username) {
		Student student = DatabaseConnection.entityManager.find(Student.class, username);
		if (student != null) {
			DatabaseConnection.entityTransaction.begin();
			DatabaseConnection.entityManager.remove(student);
			DatabaseConnection.entityTransaction.commit();
			return true;
		}
		return false;
	}
	public boolean updateDetail(String username, String address) {
		Student student = DatabaseConnection.entityManager.find(Student.class, username);
		if (student != null) {
			student.setUsername(username);
			student.setAddress(address);
			DatabaseConnection.entityTransaction.begin();
			DatabaseConnection.entityManager.merge(student);
			DatabaseConnection.entityTransaction.commit();
			return true;
		}
		return false;
	}

}
