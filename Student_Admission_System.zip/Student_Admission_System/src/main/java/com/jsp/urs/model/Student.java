package com.jsp.urs.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_info")
public class Student {
	
	@Id
	@Column(name = "username", nullable = false, updatable = false)
	private String username;
	
	@Column(name = "password", nullable = false)
	private String password;
	
	@Column(name = "email_id", nullable = false, updatable = true)
	private String email_id;
	
	@Column(name = "fullname", nullable = false)
	private String fullname;
	
	@Column(name = "dateofbirth", nullable = false, updatable = false)
	private LocalDate dob;
	
	@Column(name = "gender",  nullable = false, updatable = false)
	private String gender;
	
	@Column(name = "address",  nullable = false)
	private String address;
	
	@Column(name = "branch",  nullable = false, updatable = true)
	private String branch;
	
	@Column(name = "contact",  nullable = false, updatable = true)
	private long contact;

	public Student() {
		
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	
}
