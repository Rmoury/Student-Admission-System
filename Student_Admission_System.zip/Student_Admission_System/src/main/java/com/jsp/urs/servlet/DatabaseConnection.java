package com.jsp.urs.servlet;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;


@WebServlet(value = "/DB", loadOnStartup = 4)
public class DatabaseConnection extends HttpServlet {
	
	public static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("pgstudent");
	public static EntityManager entityManager = entityManagerFactory.createEntityManager();
	public static EntityTransaction entityTransaction = entityManager.getTransaction();
	
	public DatabaseConnection(){
		System.out.println("============================================");
		System.out.println("Database Connection Established Successfully");
		System.out.println("============================================");
	}
}
