package com.jsp.urs.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.urs.controller.ValidationController;
import com.jsp.urs.model.Student;

@WebServlet(value = "/forgot" , loadOnStartup = 3)
public class ForgotPassword extends HttpServlet{
	
	ValidationController controller = new ValidationController();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		String confirm_password = req.getParameter("confirm-password");
		
		Student student = controller.searchUsername(email);
		
		if (student != null) {
			boolean updatestatus = controller.updateUserPasswordByUserName(student, confirm_password);
			if (updatestatus) {
				PrintWriter printWriter = resp.getWriter();
				printWriter.print("<!DOCTYPE html>\r\n" + "<html lang=\"en\">\r\n" + "<head>\r\n"
						+ "    <meta charset=\"UTF-8\">\r\n"
						+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
						+ "    <title>Message</title>\r\n" + "    <script src=\"https://cdn.tailwindcss.com\"></script>\r\n"
						+ "</head>\r\n" + "<body class=\"bg-slate-300\">\r\n"
						+ "    <div class=\" m-auto w-1/4 mt-20 shadow-2xl\">\r\n"
						+ "        <div class=\"bg-green-600 px-5 py-10\">\r\n"
						+ "            <img src=\"./img/rigthlogo.png\" alt=\"LOGO\" class=\"w-1/5 m-auto\">\r\n"
						+ "            <h1 class=\"text-center text-white text-xl\">SUCCESS</h1>\r\n" + "        </div>\r\n"
						+ "        <div class=\"bg-slate-50 px-10 text-slate-500 py-5 text-center\">\r\n"
						+ "            <p class=\"mb-7\">Congratulations, your password has been change successfully. </p>\r\n"
						+ "            <a href=\"Login.html\" class=\"bg-green-600 py-2 px-14 rounded-3xl text-white\">Login</a>\r\n"
						+ "        </div>\r\n" + "    </div>\r\n" + "</body>\r\n" + "</html>");
			}
		} else {
			PrintWriter printWriter = resp.getWriter();
			printWriter.print("<html><body><script>alert(\"Invalid Credentials, Please try again\");</script></body></html>");

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("ForgotPassword.html");
			requestDispatcher.include(req, resp);
		}
		
		
	}

}
