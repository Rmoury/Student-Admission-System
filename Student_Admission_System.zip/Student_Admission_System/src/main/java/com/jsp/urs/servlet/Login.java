package com.jsp.urs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsp.urs.controller.ValidationController;
import com.jsp.urs.model.Student;

@WebServlet(value = "/login", loadOnStartup = 1)
public class Login extends HttpServlet {

	static ValidationController controller = new ValidationController();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String username = req.getParameter("username");
		String password = req.getParameter("password");

		Student user = controller.searchStudent(username, password);
		
		List<Student> allStudent = controller.allStudent();
		
		if (user != null) {
			if (controller.findAdmin(user)) {
				HttpSession session = req.getSession();
				session.setAttribute("user", user);
				session.setAttribute("allStudent", allStudent);
				resp.sendRedirect("AdminDashboard.jsp");
			} else {
				HttpSession session = req.getSession();
				session.setAttribute("student", user);
				resp.sendRedirect("StudentDashboard.jsp");
			}
					
		} else {
			PrintWriter printWriter = resp.getWriter();
			printWriter.print("<html><body><script>alert(\"Invalid Credentials, Please try again\");</script></body></html>");

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("Login.html");
			requestDispatcher.include(req, resp);
		}
	}
}
