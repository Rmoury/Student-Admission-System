package com.jsp.urs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsp.urs.controller.ValidationController;
import com.jsp.urs.model.Student;

@WebServlet(value = "/Operation" , loadOnStartup = 5)
public class Operation extends HttpServlet {
	
	ValidationController controller = new ValidationController();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 
		String link = req.getParameter("link");
		
		if(link.equals("Update Student")) {
			String username = req.getParameter("username");
			req.setAttribute("username", username);
			RequestDispatcher requestDispatcher = req.getRequestDispatcher("Update");
			requestDispatcher.forward(req, resp);
			
			
		} else if (link.equals("Delete Student")) {
			String username = req.getParameter("username");
			
			if(controller.deleteStudent(username)) {
				PrintWriter printWriter = resp.getWriter();
				printWriter.print("<!DOCTYPE html>\r\n" + "<html lang=\"en\">\r\n" + "<head>\r\n"
						+ "    <meta charset=\"UTF-8\">\r\n"
						+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
						+ "    <title>Message</title>\r\n" + "    <script src=\"https://cdn.tailwindcss.com\"></script>\r\n"
						+ "</head>\r\n" + "<body class=\"bg-slate-300\">\r\n"
						+ "    <div class=\" m-auto w-1/4 mt-20 shadow-2xl\">\r\n"
						+ "        <div class=\"bg-green-600 px-5 py-10\">\r\n"
						+ "            <img src=\"./img/rigthlogo.png\" alt=\"LOGO\" class=\"w-1/5 m-auto\">\r\n"
						+ "            <h1 class=\"text-center text-white text-xl\">SUCCESS</h1>\r\n" + "        </div>\r\n"
						+ "        <div class=\"bg-slate-50 px-10 text-slate-500 py-5 text-center\">\r\n"
						+ "            <p class=\"mb-7\">Congratulations, your account has been successfully Deleted. </p>\r\n"
						+ "            <a href=\"Login.html\" class=\"bg-green-600 py-2 px-14 rounded-3xl text-white\">Login</a>\r\n"
						+ "        </div>\r\n" + "    </div>\r\n" + "</body>\r\n" + "</html>");
			}
		}
	}

}
