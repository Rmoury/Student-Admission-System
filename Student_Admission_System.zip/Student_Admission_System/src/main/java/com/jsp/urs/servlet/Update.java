package com.jsp.urs.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value = "/Update", loadOnStartup = 6)
public class Update extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String username = (String) req.getAttribute("username");
		
		PrintWriter printWriter = resp.getWriter();
		printWriter.print("<!DOCTYPE html>\r\n"
				+ "<html lang=\"en\">\r\n"
				+ "\r\n"
				+ "<head>\r\n"
				+ "    <meta charset=\"UTF-8\">\r\n"
				+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
				+ "    <title>User Registration</title>\r\n"
				+ "    <script src=\"https://cdn.tailwindcss.com\"></script>\r\n"
				+ "</head>\r\n"
				+ "\r\n"
				+ "<body\r\n"
				+ "    style=\"background-image: url(https://s3.amazonaws.com/cms.ipressroom.com/401/files/202306/6487c441a1383573c179423e_CampusConvo_LnS_FINAL/CampusConvo_LnS_FINAL_c07be7ca-db43-4737-a9ea-f6263c702e38-prv.jpg); background-size: cover;\">\r\n"
				+ "    <form action=\"UpdateAddress\">\r\n"
				+ "        <div class=\"m-auto w-2/3 mt-10 shadow-2xl bg-slate-50 md:w-2/5\">\r\n"
				+ "            <div class=\"bg-blue-500 p-5 text-center\">\r\n"
				+ "                <h1 class=\" text-3xl font-bold text-white\">Student Updatation</h1>\r\n"
				+ "            </div>\r\n"
				+ "            <div class=\"px-10 py-5\">\r\n"
				+ "\r\n"
				+ "                <label for=\"username\" class=\"font-mono mr-3\">Username : </label>\r\n"
				+ "               <input type=\"text\" name=\"username\" id=\"username\" value=\""+username+"\"><br>\r\n"
				+ "\r\n"
				+ "                <label for=\"address\" class=\"font-mono mr-3\">Address</label>\r\n"
				+ "                <input type=\"text\" id=\"address\" name=\"address\" class=\"py-1 px-4 mb-5  bg-slate-200 w-5/6 md:w-2/4\"\r\n"
				+ "                    required /><br>\r\n"
				+ "\r\n"
				+ "                    <label for=\"password\" class=\"font-mono mr-3\">Admin Password</label>\r\n"
				+ "                <input type=\"password\" id=\"password\" name=\"password\" class=\"py-1 px-4 mb-5  bg-slate-200 w-5/6 md:w-2/4\"\r\n"
				+ "                    required /><br>\r\n"
				+ "\r\n"
				+ "                    <input type=\"submit\" value=\"Update\"\r\n"
				+ "                    class=\"py-2 px-4 mb-5 rounded-2xl text-white bg-blue-500 w-5/6 md:w-5/6 cursor-progress\">\r\n"
				+ "            </div>\r\n"
				+ "        </div>\r\n"
				+ "    </form>\r\n"
				+ "</body>\r\n"
				+ "\r\n"
				+ "</html>");
	}

}
